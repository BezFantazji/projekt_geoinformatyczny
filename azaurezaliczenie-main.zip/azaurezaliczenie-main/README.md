# azaurezaliczenie
Zaliczenie azure
